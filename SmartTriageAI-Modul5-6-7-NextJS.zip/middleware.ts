import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { SESSION_COOKIE } from "@/lib/constants";
import { getHomeRouteForRole } from "@/lib/role-routes";

/**
 * middleware.ts - Server-Side Access Control & Route Guard (Modul 6, poin F).
 * Dieksekusi di server SEBELUM request mencapai komponen halaman manapun.
 * Middleware sengaja hanya memeriksa KEBERADAAN cookie sesi (bukan
 * memvalidasi isi lengkapnya dengan Zod) karena Edge Runtime tempat
 * middleware berjalan membatasi beberapa API Node.js — validasi isi penuh
 * tetap dilakukan lewat getSession() di Server Component/Route Handler.
 */
const PROTECTED_PREFIXES = [
  "/dashboard",
  "/triase",
  "/admin",
  "/pasien",
  "/riwayat-pasien",
  "/asesmen-visual",
  "/superadmin",
  "/auditor",
  "/dinas-kesehatan",
  "/profil",
];

export function middleware(request: NextRequest) {
  const sessionCookie = request.cookies.get(SESSION_COOKIE)?.value;
  const isProtectedRoute = PROTECTED_PREFIXES.some((p) => request.nextUrl.pathname.startsWith(p));

  if (isProtectedRoute && !sessionCookie) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("auth_error", "1");
    return NextResponse.redirect(loginUrl);
  }

  // Pengguna yang sudah login tidak perlu melihat halaman login lagi.
  // Parsing JSON sederhana di sini aman untuk Edge Runtime (bukan Node API
  // seperti next/headers); validasi Zod penuh tetap di getSession() sisi
  // Server Component/Route Handler.
  if (request.nextUrl.pathname === "/login" && sessionCookie) {
    let role: unknown;
    try {
      role = (JSON.parse(sessionCookie) as { role?: unknown }).role;
    } catch {
      role = undefined;
    }
    return NextResponse.redirect(new URL(getHomeRouteForRole(role), request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/triase/:path*",
    "/admin/:path*",
    "/pasien/:path*",
    "/riwayat-pasien/:path*",
    "/asesmen-visual/:path*",
    "/superadmin/:path*",
    "/auditor/:path*",
    "/dinas-kesehatan/:path*",
    "/profil/:path*",
    "/login",
  ],
};
